// app.js

function init () {
  document.body.appendChild(document.createTextNode('another fraud'))
}

window.onload = init
